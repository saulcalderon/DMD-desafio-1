 --Seleccionar los 20 clientes frecuentes
SELECT TOP 20 d.id, 
	CASE WHEN d.Sexo = 1 THEN 'Mujer'
    WHEN d.Sexo = 0 THEN 'Hombre'
	END AS Genero, d.ingresos, CAST(d.PromVisit as numeric(10,2)) AS promedio_visita
	FROM data d
	ORDER BY promedio_visita DESC

 --Seleccionar los 20 clientes frecuentes con m�s ingresos
--SELECT TOP 20 d.id, 
--	CASE WHEN d.Sexo = 1 THEN 'Mujer'
--    WHEN d.Sexo = 0 THEN 'Hombre'
--	END AS Genero, CONVERT(numeric(18,2), d.ingresos) AS ingresos, CAST(d.PromVisit as numeric(10,2)) AS promedio_visita
--	FROM data d
--	ORDER BY ingresos DESC, promedio_visita DESC;

 --Seleccionar que genero utiliza m�s los servicios del spa	
--SELECT
--	CASE WHEN d.Sexo = 1 THEN 'Mujer'
--    WHEN d.Sexo = 0 THEN 'Hombre'
--	END AS Genero, SUM(CONVERT(int, d.Sauna) + CONVERT(int, d.Masaje) + CONVERT(int, d.Hidro) + CONVERT(int, d.Yoga)) AS total_servicios
--	FROM data d
--	GROUP BY d.Sexo
--	ORDER BY total_servicios DESC;
	